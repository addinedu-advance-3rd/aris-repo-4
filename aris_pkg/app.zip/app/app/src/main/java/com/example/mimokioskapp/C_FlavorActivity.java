package com.example.mimokioskapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class C_FlavorActivity extends AppCompatActivity {

    private static final String CLIENT_ID = "a4zgp0vwh8"; // 네이버 클라이언트 ID
    private static final String CLIENT_SECRET = "IB5GVyMe4O255EB2u61vHfZMla9GVZ87GcWEuMhW"; // 네이버 클라이언트 Secret


    private String languageMode = "";
    private String selectedFlavor = "";
    private ToggleButton language_btn;
    private ImageButton strawberry_btn, blueberry_btn;

    private TextView order_text;

    private SpeechRecognizer speechRecognizer;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_flavor);

        strawberry_btn = findViewById(R.id.strawberry_btn);
        blueberry_btn = findViewById(R.id.blueberry_btn);
        language_btn = findViewById(R.id.language_btn);
        order_text = findViewById(R.id.order_text);

        languageMode = getIntent().getStringExtra("languageMode");
        // 언어 설정 버튼 클릭 리스너
        language_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((ToggleButton)v).isChecked();

                if (checked) {
                    language_btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.eng_img));
                    languageMode = "eng";
                    order_text.setText("Please choose the flavor you want");

                } else {
                    language_btn.setBackgroundDrawable(getResources().getDrawable(R.drawable.kor_img));
                    languageMode = "ko";
                    order_text.setText("원하는 맛을 선택해주세요");

                }
            }
        });


        if ("ko".equals(languageMode)){
            new TTSAsyncTask().execute("무슨 맛으로 선택하시겠어요? 딸기 맛과 블루베리 맛이 있어요.");
        } else if ("eng".equals(languageMode)){
            new TTSAsyncTask().execute("What flavor would you like to have? We have strawberry and blueberry flavors.");

        }
        startListeningForFlavorSelection();




        strawberry_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedFlavor = "strawberry";
                Intent intent = new Intent(C_FlavorActivity.this, D_ToppingActivity.class);
                intent.putExtra("selectedFlavor", selectedFlavor);
                startActivity(intent);
            }
        });

        blueberry_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedFlavor = "blueberry";
                Intent intent = new Intent(C_FlavorActivity.this, D_ToppingActivity.class);
                intent.putExtra("selectedFlavor", selectedFlavor);
                startActivity(intent);
            }
        });
        startListeningForFlavorSelection();
    }
    private class TTSAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String text = URLEncoder.encode(params[0], "UTF-8"); // 텍스트 인코딩
                String apiURL = "https://naveropenapi.apigw.ntruss.com/tts-premium/v1/tts";
                URL url = new URL(apiURL);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("X-NCP-APIGW-API-KEY-ID", CLIENT_ID);
                con.setRequestProperty("X-NCP-APIGW-API-KEY", CLIENT_SECRET);

                // POST 요청 파라미터
                String postParams = "speaker=nara&volume=0&speed=0&pitch=0&format=mp3&text=" + text;
                con.setDoOutput(true);
                DataOutputStream wr = new DataOutputStream(con.getOutputStream());
                wr.writeBytes(postParams);
                wr.flush();
                wr.close();

                int responseCode = con.getResponseCode();
                BufferedReader br;
                if (responseCode == 200) { // 정상 호출
                    InputStream is = con.getInputStream();
                    int read;
                    byte[] bytes = new byte[1024];

                    // 랜덤한 이름으로 mp3 파일 생성
                    String tempname = String.valueOf(System.currentTimeMillis());
                    File file = new File(getExternalFilesDir(null), tempname + ".mp3");
                    file.createNewFile();
                    OutputStream outputStream = new FileOutputStream(file);
                    while ((read = is.read(bytes)) != -1) {
                        outputStream.write(bytes, 0, read);
                    }
                    is.close();
                    outputStream.close();

                    return file.getAbsolutePath(); // 파일 경로 반환
                } else {  // 오류 발생
                    br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = br.readLine()) != null) {
                        response.append(inputLine);
                    }
                    br.close();
                    return response.toString();
                }
            } catch (IOException e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // 결과 처리
            if (result.endsWith(".mp3")) {
                // MP3 파일이 생성되었으므로 이를 재생하는 코드 추가
                MediaPlayer mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(result); // 생성된 MP3 파일 경로를 전달
                    mediaPlayer.prepare(); // 파일 준비
                    mediaPlayer.start(); // 음성 재생 시작

                    Toast.makeText(C_FlavorActivity.this, "음성 파일이 생성되었고 재생되었습니다: " + result, Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(C_FlavorActivity.this, "음성 파일 재생 오류: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                // 오류 메시지 처리
                Toast.makeText(C_FlavorActivity.this, "TTS 오류: " + result, Toast.LENGTH_LONG).show();
            }
        }
    }



    public void startListeningForFlavorSelection() {
        try {
            // 음성 파일 경로 설정
            String imgFile = "음성 파일 경로"; // 음성 파일 경로를 실제 경로로 설정해야 합니다.
            File voiceFile = new File(imgFile);

            // Naver STT API 호출을 위한 언어 설정
            String language = "Kor"; // 한국어로 설정
            String apiURL = "https://naveropenapi.apigw.ntruss.com/recog/v1/stt?lang=" + language;
            URL url = new URL(apiURL);

            // HTTP 연결 설정
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            conn.setRequestProperty("X-NCP-APIGW-API-KEY-ID", CLIENT_ID); // 네이버 클라이언트 ID
            conn.setRequestProperty("X-NCP-APIGW-API-KEY", CLIENT_SECRET); // 네이버 클라이언트 Secret

            // 음성 파일 전송
            OutputStream outputStream = conn.getOutputStream();
            FileInputStream inputStream = new FileInputStream(voiceFile);
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            outputStream.flush();
            inputStream.close();

            // 응답 처리
            BufferedReader br;
            int responseCode = conn.getResponseCode();
            if (responseCode == 200) { // 정상 호출
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            } else { // 오류 발생
                System.out.println("error!!!!!!! responseCode= " + responseCode);
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream())); // 에러 스트림 처리
            }

            // 응답 결과 처리
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();

            // 응답 결과 출력
            System.out.println("STT 결과: " + response.toString());

            // 결과를 처리하는 방법을 정의 (예: 딸기 또는 블루베리 선택)
            if (response.toString().contains("딸기") || response.toString().contains("strawberry")) {
                // '딸기' 또는 'strawberry' 키워드가 인식되면 딸기 선택
                selectStrawberry();
            } else if (response.toString().contains("블루베리") || response.toString().contains("blueberry")) {
                // '블루베리' 또는 'blueberry' 키워드가 인식되면 블루베리 선택
                selectBlueberry();
            } else {
                // 음성이 인식되지 않거나 다른 텍스트가 인식되면 다시 음성 인식 시작
                Toast.makeText(C_FlavorActivity.this, "맛을 인식하지 못했습니다. 다시 시도해주세요.", Toast.LENGTH_LONG).show();
                startListeningForFlavorSelection(); // 재시도
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(C_FlavorActivity.this, "STT 오류: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void selectStrawberry() {
        // 딸기 선택 후 TTS로 알려주기
        if (languageMode.equals("ko")){
            new TTSAsyncTask().execute("딸기맛으로 선택하셨습니다.");
        } else if (languageMode.equals("eng")) {
            new TTSAsyncTask().execute("You have chosen the strawberry flavor.");
        }
        goToNextScreen();
    }

    private void selectBlueberry() {
        // 딸기 선택 후 TTS로 알려주기
        if (languageMode.equals("ko")){
            new TTSAsyncTask().execute("블루베리맛으로 선택하셨습니다.");
        } else if (languageMode.equals("eng")) {
            new TTSAsyncTask().execute("You have chosen the blueberry flavor.");
        }
        goToNextScreen();
    }

    private void goToNextScreen() {
        // 다음 화면으로 이동
        Intent intent = new Intent(C_FlavorActivity.this, D_ToppingActivity.class);
        intent.putExtra("selectedFlavor", selectedFlavor);
        intent.putExtra("languageMode", languageMode); // 언어 정보 전달
        startActivity(intent);
        finish();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy(); // 리소스 해제
        }
    }
}



