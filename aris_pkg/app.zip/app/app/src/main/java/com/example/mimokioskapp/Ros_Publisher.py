from py4j.clientserver import JavaGateway, GatewayParameters, CallbackServerParameters

class RosPublisher:
    def __init__(self):
        pass

    def publishOrderInfo(self, selectedFlavor, checkTopping1, checkTopping2, checkTopping3, totalPrice):
        # 구현된 내용 출력
        print(f"Flavor: {selectedFlavor}, Topping 1: {checkTopping1}, Topping 2: {checkTopping2}, "
              f"Topping 3: {checkTopping3}, Total Price: {totalPrice}")

class PythonServer:
    def __init__(self):
        self.publisher = RosPublisher()

    def getRosPublisher(self):
        return self.publisher

# Py4J 서버 실행
gateway = JavaGateway(gateway_parameters=GatewayParameters(port=25333),
                      callback_server_parameters=CallbackServerParameters(port=0))

python_server = PythonServer()
gateway.entry_point = python_server
print("Python server is running...")
