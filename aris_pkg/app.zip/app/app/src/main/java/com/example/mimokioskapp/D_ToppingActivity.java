package com.example.mimokioskapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import py4j.GatewayServer;

public class D_ToppingActivity extends Activity {
    // 뷰 요소 선언
    private CheckBox checkTopping1, checkTopping2, checkTopping3;
    private RadioButton yes_btn, none_btn;
    private Button topping_btn;
    private LinearLayout topping_ly;
    private RadioGroup rg;
    private TextView text_price;

    private String selectedFlavor = ""; // 선택된 맛

    // 가격 관련 변수
    private int basePrice = 4000; // 기본 가격
    private int toppingPrice = 300; // 토핑 가격
    private int totalPrice = 4000; // 총 가격

    private RosPublisher rosPublisher; // ROS 퍼블리셔 객체

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_topping); // 레이아웃 설정

        // 선택된 맛을 인텐트에서 받음
        selectedFlavor = getIntent().getStringExtra("selectedFlavor");
        if (selectedFlavor != null) {
            Toast.makeText(this, "선택된 맛: " + selectedFlavor, Toast.LENGTH_SHORT).show(); // 맛 표시
        }

        // 뷰 요소 초기화
        checkTopping1 = findViewById(R.id.checkTopping1);
        checkTopping2 = findViewById(R.id.checkTopping2);
        checkTopping3 = findViewById(R.id.checkTopping3);
        yes_btn = findViewById(R.id.yes_btn);
        none_btn = findViewById(R.id.none_btn);
        topping_btn = findViewById(R.id.topping_btn);
        topping_ly = findViewById(R.id.topping_ly);
        text_price = findViewById(R.id.text_price);
        rg = findViewById(R.id.rg);

        // 라디오 버튼 클릭 리스너 설정
        rg.setOnCheckedChangeListener(radioGroupClickListener);

        // 가격 업데이트 리스너 설정
        View.OnClickListener updatePriceListener = view -> updateTotalPrice();
        checkTopping1.setOnClickListener(updatePriceListener);
        checkTopping2.setOnClickListener(updatePriceListener);
        checkTopping3.setOnClickListener(updatePriceListener);

        // 토핑 버튼 클릭 리스너 설정
        topping_btn.setOnClickListener(view -> confirmSelection());

        // Py4J 초기화 및 RosPublisher 객체 가져오기
        GatewayServer gatewayServer = new GatewayServer(this);
        gatewayServer.start();
        rosPublisher = (RosPublisher) gatewayServer.getPythonServerEntryPoint();
    }

    // 라디오 버튼 클릭 리스너
    RadioGroup.OnCheckedChangeListener radioGroupClickListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.yes_btn) {
                topping_ly.setVisibility(View.VISIBLE); // 토핑 선택 레이아웃을 보이게 함
                updateTotalPrice(); // 가격 업데이트
            } else if (checkedId == R.id.none_btn) {
                topping_ly.setVisibility(View.INVISIBLE); // 토핑 선택 레이아웃을 숨김
                clearToppingSelection(); // 토핑 선택 초기화
                resetPrice(); // 가격 초기화
            }
        }
    };

    // 총 가격을 업데이트하는 메서드
    private void updateTotalPrice() {
        totalPrice = basePrice; // 기본 가격으로 초기화
        if (yes_btn.isChecked()) { // 토핑을 선택한 경우
            if (checkTopping1.isChecked()) totalPrice += toppingPrice; // 토핑 1 추가
            if (checkTopping2.isChecked()) totalPrice += toppingPrice; // 토핑 2 추가
            if (checkTopping3.isChecked()) totalPrice += toppingPrice; // 토핑 3 추가
        }

        text_price.setText("금액: " + totalPrice + "원"); // 화면에 가격 표시
    }

    // 토핑 선택 초기화하는 메서드
    private void clearToppingSelection() {
        checkTopping1.setChecked(false);
        checkTopping2.setChecked(false);
        checkTopping3.setChecked(false);
    }

    // 가격을 초기화하는 메서드
    private void resetPrice() {
        totalPrice = basePrice;
        text_price.setText("금액 : " + totalPrice + "원"); // 기본 가격으로 초기화
    }

    // 선택 확인 후, 다른 Activity로 이동하는 메서드
    private void confirmSelection() {
        // 선택된 내용을 Python 서버로 전달
        String toppingMessage = "Selected Flavor: " + selectedFlavor
                + ", Topping 1: " + (checkTopping1.isChecked() ? "Yes" : "No")
                + ", Topping 2: " + (checkTopping2.isChecked() ? "Yes" : "No")
                + ", Topping 3: " + (checkTopping3.isChecked() ? "Yes" : "No")
                + ", Total Price: " + totalPrice;

        // Python 서버로 메시지 전송
        sendMessageToPython(toppingMessage);

        // 결제 화면으로 이동
        Intent intent = new Intent(D_ToppingActivity.this, E_PaymentActivity.class);
        intent.putExtra("totalPrice", totalPrice); // 총 가격 전달
        intent.putExtra("selectedFlavor", selectedFlavor); // 선택된 맛 전달
        startActivity(intent);
    }

    // Python 서버로 메시지 전송하는 메서드
    private void sendMessageToPython(String message) {
        try {
            // RosPublisher 객체를 통해 메시지 전송
            if (rosPublisher != null) {
                rosPublisher.publishOrderInfo(selectedFlavor,
                        checkTopping1.isChecked(),
                        checkTopping2.isChecked(),
                        checkTopping3.isChecked(),
                        totalPrice);  // 메시지 전송
            }
        } catch (Exception e) {
            e.printStackTrace(); // 예외 처리
        }
    }
}
