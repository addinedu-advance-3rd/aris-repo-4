package com.example.mimokioskapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION =1;

    public DatabaseHelper(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //products 테이블 생성
        String createProductsTable = "CREATE TABLE products ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "+
                "name TEXT, "+
                "category TEXT, "+
                "price FLOAT, "+
                "stock_quantity INTEGER)";
        db.execSQL(createProductsTable);
        //orders 테이블 생성
        String createOrdersTable = "CREATE TABLE orders ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "+
                "product_id INTEGER, "+
                "quantity INTEGER, "+
                "status TEXT, "+
                "FOREIGN KEY (product_id) REFERENCES products(id))";
        db.execSQL(createOrdersTable);

        //초기 데이터 삽입
        addSampleData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS products");
        db.execSQL("DROP TABLE IF EXISTS orders");
        onCreate(db);

    }

    //초기 데이터 삽입
    public void addSampleData(SQLiteDatabase db) {
        //아이스크림 캡슐 추가
        addProduct(db, "딸기 맛", "ice_cream",4000,50);
        addProduct(db, "블루베리 맛", "ice_cream",4000,50);

        //토핑 추가
        addProduct(db, "죠리퐁", "topping", 300, 100);
        addProduct(db, "코코볼", "topping", 300, 100);
        addProduct(db, "해바라기씨", "topping", 300, 100);

        //용기 추가
        addProduct(db, "컵", "container", 0, 50);
        addProduct(db, "콘", "container", 0, 50);
    }

    //제품 추가
    private void addProduct(SQLiteDatabase db, String name, String category, float price, int stockQuantity) {
        ContentValues values = new ContentValues();
        values.put("name",name);
        values.put("category",category);
        values.put("price",price);
        values.put("stock_quantity", stockQuantity);
        db.insert("products", null, values);
    }

    //제품 목록 조회
    public Cursor getProducts(){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM products", null);
    }

    //제품 재고 업데이트
    public void updateProductStock(int productId, int newQuantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("stock_quantity", newQuantity);
        db.update("products", values,"id=?",new String[]{String.valueOf(productId)});
    }

    //주문 추가
    public void addOrder(int productId, int quantity, String status){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("product_id",productId);
        values.put("quantity",quantity);
        values.put("status",status);
        db.insert("orders",null,values);
    }

    //주문 처리 (재고 차감)
    public void processOrder(int productId, int quantity){
        SQLiteDatabase db = this.getWritableDatabase();

        //제품의 재고 수량을 조회
        Cursor cursor = db.rawQuery("SELECT stock_quantity FROM products WHERE id = ?", new String[]{String.valueOf(productId)});
        if (cursor.moveToFirst()){
            int stock = cursor.getInt(0);
            if (stock >=quantity){
                int newStock = stock -quantity;
                updateProductStock(productId,newStock);  //재고 업데이트

                //주문 추가
                addOrder(productId,quantity,"대기");
            } else {
                Log.d("Inventory", "재고가 부족합니다.");
            }
        }
        cursor.close();
    }

    public void updateOrderStatus(int orderId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status",status);
        db.update("orders",values,"id=?",new String[]{String.valueOf(orderId)});
    }
}