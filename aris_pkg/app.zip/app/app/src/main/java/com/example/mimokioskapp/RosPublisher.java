package com.example.mimokioskapp;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.ros.node.AbstractNodeMain;
import org.ros.node.Node;
import org.ros.node.topic.Publisher;
import std_msgs.String;


public class RosPublisher {
   private static final String SERVER_URL="#" ;//파이썬 서버 ip

    @Override
    public void onStart(Node node) {
        Publisher<std_msgs.String> publisher = node.newPublisher("/order_status", std_msgs.String._TYPE);
        std_msgs.String message = publisher.newMessage();
        message.setData("Hello, ROS!");
        publisher.publish(message);
    }

    @Override
    public GraphName getDefaultNodeName() {
        return GraphName.of("my_publisher_node");
    }
}


